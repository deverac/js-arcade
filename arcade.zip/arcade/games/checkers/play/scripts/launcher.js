((typeof global === "object" && global &&
         global["Object"] === Object) ? global : this)["checkers"]["CheckersMain"]().main();
