var
    // Static server
    SS = '',
    FULLADDR = '',
    // Backend API address
    API_ADDR = '',
    // Game version
    VERSION = '1.0.0',
    // Revision of your all static files (after update you should increase this value)
    REVISION = '?v=1',
    // Availables episodes
    EPISODES = ['space', 'pegasus'],
    ENV = 'prod';